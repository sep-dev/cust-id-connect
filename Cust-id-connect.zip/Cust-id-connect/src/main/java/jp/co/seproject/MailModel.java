package jp.co.seproject;

public class MailModel {
	private String to;
	private String subject;
	private String honbun;


	public String getTo() {
		return to;
	}

	public void setTo(String to) {
		this.to = to;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getHonbun() {
		return honbun;
	}

	public void setHonbun(String honbun) {
		this.honbun = honbun;
	}



}
